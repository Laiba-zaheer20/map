#pragma once
ref class matrixs
{
public:
	matrixs(void);
	int matrixs::matrixsall(void);
};

