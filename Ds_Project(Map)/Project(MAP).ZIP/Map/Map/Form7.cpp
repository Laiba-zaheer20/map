#include "StdAfx.h"
#include "Form7.h"

//namespace Map{

//public: System::int min(int g,int j,int v) {
			  	
	//		 int graph[9][9] = {
		/*bun b*/		 //    {0, 4, 0, 0, 0, 0, 0, 8, 0}, 
    /*house 111*/       //     {4, 0, 8, 0, 0, 0, 0, 11, 0}, 
            /*optp*/     //    {0, 8, 0, 7, 0, 4, 0, 0, 2}, 
            /*house 161*/  //  {0, 0, 7, 0, 9, 14, 0, 0, 0}, 
    /*kfc*/                //  {0, 0, 0, 9, 0, 10, 0, 0, 0}, 
     /*house 181*/         //  {0, 0, 4, 0, 10, 0, 2, 0, 0}, 
   /*ginsoy*/               /// {0, 0, 0, 14, 0, 2, 0, 1, 6}, 
   /*sams*/                //  {8, 11, 0, 0, 0, 0, 1, 0, 7}, 
    /*house 121*/           // {0, 0, 2, 0, 0, 0, 6, 7, 0},
		//	 };
		// int r;
		// for( int v=1;v<9;v++){
			 //if(graph[j][v]<g&&graph[j][v]>0){
			//	 min=graph[j][v];
			//	 u=min;
			//	r=v;//index of the shortest distance
		//	 }//end if
		 
		// }//end for
//
//}