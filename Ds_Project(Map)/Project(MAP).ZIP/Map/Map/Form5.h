#pragma once

#include "StdAfx.h"
#include "runit.h"
#include<String>

namespace Map {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form5
	/// </summary>
	public ref class Form5 : public System::Windows::Forms::Form
	{
	public:
		 static array<String^>^ names = gcnew array<String^>(9);
		Form5(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
				    names[0]="Bun-B";
					names[1]="House 111";
					names[2]="Optp";
					names[3]="House 161";
					names[4]="KFC";
					names[5]="House 181";
					names[6]="Ginsoy";
					names[7]="Sams";
					names[8]="House 121";

			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form5()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ListBox^  Distance;
	private: System::Windows::Forms::Button^  close;
	private: System::Windows::Forms::Panel^  panel2;
	public: System::Windows::Forms::Label^  label5;
	private: 
	public: System::Windows::Forms::Label^  label4;
	public: System::Windows::Forms::Label^  label11;
	public: System::Windows::Forms::Label^  label6;
	public: System::Windows::Forms::Label^  label10;
	public: System::Windows::Forms::Label^  label3;
	public: System::Windows::Forms::Label^  label9;
	public: System::Windows::Forms::Label^  label8;
	public: System::Windows::Forms::Label^  label7;
	private: Microsoft::VisualBasic::PowerPacks::ShapeContainer^  shapeContainer1;
	public: 
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape13;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape12;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape11;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape10;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape9;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape8;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape5;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape4;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape3;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape2;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape1;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form5::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Distance = (gcnew System::Windows::Forms::ListBox());
			this->close = (gcnew System::Windows::Forms::Button());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->shapeContainer1 = (gcnew Microsoft::VisualBasic::PowerPacks::ShapeContainer());
			this->lineShape13 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape12 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape11 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape10 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape9 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape8 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape5 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape4 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape3 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape2 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape1 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::LightSalmon;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::Red;
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Britannic Bold", 25.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(-1, 12);
			this->button1->Margin = System::Windows::Forms::Padding(2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(243, 50);
			this->button1->TabIndex = 3;
			this->button1->Text = L"Shortest Path";
			this->button1->UseVisualStyleBackColor = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::LightSalmon;
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->comboBox2);
			this->panel1->Controls->Add(this->comboBox1);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Location = System::Drawing::Point(9, 80);
			this->panel1->Margin = System::Windows::Forms::Padding(2);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(204, 228);
			this->panel1->TabIndex = 4;
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Teal;
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(51, 115);
			this->button2->Margin = System::Windows::Forms::Padding(2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 29);
			this->button2->TabIndex = 4;
			this->button2->Text = L"Search";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Form5::button2_Click);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(9) {L"Ginsoy", L"Optp", L"House 161", L"House 111", 
				L"House 181", L"House 121", L"Bun-B", L"KFC", L"Sams"});
			this->comboBox2->Location = System::Drawing::Point(92, 78);
			this->comboBox2->Margin = System::Windows::Forms::Padding(2);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(101, 21);
			this->comboBox2->TabIndex = 3;
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(9) {L"Ginsoy", L"Optp", L"House 161", L"House 111", 
				L"House 181", L"House 121", L"Bun-B", L"KFC", L"Sams"});
			this->comboBox1->Location = System::Drawing::Point(92, 40);
			this->comboBox1->Margin = System::Windows::Forms::Padding(2);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(101, 21);
			this->comboBox1->TabIndex = 2;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 79);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(88, 15);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Destination :";
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(12, 31);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(75, 37);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Current Location :";
			// 
			// Distance
			// 
			this->Distance->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->Distance->Font = (gcnew System::Drawing::Font(L"Franklin Gothic Medium", 10.2F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Distance->FormattingEnabled = true;
			this->Distance->ItemHeight = 18;
			this->Distance->Location = System::Drawing::Point(9, 313);
			this->Distance->Margin = System::Windows::Forms::Padding(2);
			this->Distance->Name = L"Distance";
			this->Distance->Size = System::Drawing::Size(678, 94);
			this->Distance->TabIndex = 5;
			// 
			// close
			// 
			this->close->BackColor = System::Drawing::Color::Teal;
			this->close->ForeColor = System::Drawing::Color::White;
			this->close->Location = System::Drawing::Point(612, 428);
			this->close->Name = L"close";
			this->close->Size = System::Drawing::Size(75, 29);
			this->close->TabIndex = 6;
			this->close->Text = L"Close";
			this->close->UseVisualStyleBackColor = false;
			this->close->Click += gcnew System::EventHandler(this, &Form5::close_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::LightSalmon;
			this->panel2->Controls->Add(this->label5);
			this->panel2->Controls->Add(this->label4);
			this->panel2->Controls->Add(this->label11);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->label10);
			this->panel2->Controls->Add(this->label3);
			this->panel2->Controls->Add(this->label9);
			this->panel2->Controls->Add(this->label8);
			this->panel2->Controls->Add(this->label7);
			this->panel2->Controls->Add(this->shapeContainer1);
			this->panel2->Location = System::Drawing::Point(257, 12);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(430, 296);
			this->panel2->TabIndex = 25;
			// 
			// label5
			// 
			this->label5->BackColor = System::Drawing::Color::White;
			this->label5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label5.Image")));
			this->label5->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label5->Location = System::Drawing::Point(196, 82);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(87, 32);
			this->label5->TabIndex = 29;
			this->label5->Text = L"House 161";
			this->label5->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label4
			// 
			this->label4->BackColor = System::Drawing::Color::White;
			this->label4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label4.Image")));
			this->label4->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label4->Location = System::Drawing::Point(143, 14);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(86, 30);
			this->label4->TabIndex = 28;
			this->label4->Text = L"Bun-B";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label11
			// 
			this->label11->BackColor = System::Drawing::Color::White;
			this->label11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label11->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label11.Image")));
			this->label11->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label11->Location = System::Drawing::Point(125, 125);
			this->label11->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(83, 28);
			this->label11->TabIndex = 31;
			this->label11->Text = L"House 121";
			this->label11->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label6
			// 
			this->label6->BackColor = System::Drawing::Color::White;
			this->label6->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label6.Image")));
			this->label6->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label6->Location = System::Drawing::Point(237, 237);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(79, 30);
			this->label6->TabIndex = 30;
			this->label6->Text = L"KFC";
			this->label6->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label10
			// 
			this->label10->BackColor = System::Drawing::Color::White;
			this->label10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label10->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label10.Image")));
			this->label10->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label10->Location = System::Drawing::Point(319, 118);
			this->label10->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(91, 31);
			this->label10->TabIndex = 33;
			this->label10->Text = L"Optp";
			this->label10->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label3
			// 
			this->label3->BackColor = System::Drawing::Color::White;
			this->label3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label3.Image")));
			this->label3->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label3->Location = System::Drawing::Point(275, 46);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(103, 32);
			this->label3->TabIndex = 27;
			this->label3->Text = L"House 111";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label9
			// 
			this->label9->BackColor = System::Drawing::Color::White;
			this->label9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label9->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label9.Image")));
			this->label9->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label9->Location = System::Drawing::Point(3, 176);
			this->label9->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(80, 31);
			this->label9->TabIndex = 26;
			this->label9->Text = L"Ginsoy";
			this->label9->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label8
			// 
			this->label8->BackColor = System::Drawing::Color::White;
			this->label8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label8.Image")));
			this->label8->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label8->Location = System::Drawing::Point(81, 234);
			this->label8->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(90, 36);
			this->label8->TabIndex = 32;
			this->label8->Text = L"House 181";
			this->label8->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// label7
			// 
			this->label7->BackColor = System::Drawing::Color::White;
			this->label7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label7.Image")));
			this->label7->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label7->Location = System::Drawing::Point(37, 80);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(80, 31);
			this->label7->TabIndex = 25;
			this->label7->Text = L"Sams";
			this->label7->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// shapeContainer1
			// 
			this->shapeContainer1->Location = System::Drawing::Point(0, 0);
			this->shapeContainer1->Margin = System::Windows::Forms::Padding(0);
			this->shapeContainer1->Name = L"shapeContainer1";
			this->shapeContainer1->Shapes->AddRange(gcnew cli::array< Microsoft::VisualBasic::PowerPacks::Shape^  >(11) {this->lineShape13, 
				this->lineShape12, this->lineShape11, this->lineShape10, this->lineShape9, this->lineShape8, this->lineShape5, this->lineShape4, 
				this->lineShape3, this->lineShape2, this->lineShape1});
			this->shapeContainer1->Size = System::Drawing::Size(430, 296);
			this->shapeContainer1->TabIndex = 0;
			this->shapeContainer1->TabStop = false;
			// 
			// lineShape13
			// 
			this->lineShape13->Name = L"lineShape13";
			this->lineShape13->X1 = 322;
			this->lineShape13->X2 = 286;
			this->lineShape13->Y1 = 133;
			this->lineShape13->Y2 = 105;
			// 
			// lineShape12
			// 
			this->lineShape12->Name = L"lineShape12";
			this->lineShape12->X1 = 328;
			this->lineShape12->X2 = 327;
			this->lineShape12->Y1 = 112;
			this->lineShape12->Y2 = 73;
			// 
			// lineShape11
			// 
			this->lineShape11->Name = L"lineShape11";
			this->lineShape11->X1 = 166;
			this->lineShape11->X2 = 167;
			this->lineShape11->Y1 = 122;
			this->lineShape11->Y2 = 40;
			// 
			// lineShape10
			// 
			this->lineShape10->Name = L"lineShape10";
			this->lineShape10->X1 = 212;
			this->lineShape10->X2 = 211;
			this->lineShape10->Y1 = 80;
			this->lineShape10->Y2 = 40;
			// 
			// lineShape9
			// 
			this->lineShape9->Name = L"lineShape9";
			this->lineShape9->X1 = 258;
			this->lineShape9->X2 = 241;
			this->lineShape9->Y1 = 232;
			this->lineShape9->Y2 = 112;
			// 
			// lineShape8
			// 
			this->lineShape8->Name = L"lineShape8";
			this->lineShape8->X1 = 229;
			this->lineShape8->X2 = 293;
			this->lineShape8->Y1 = 27;
			this->lineShape8->Y2 = 43;
			// 
			// lineShape5
			// 
			this->lineShape5->Name = L"lineShape5";
			this->lineShape5->X1 = 249;
			this->lineShape5->X2 = 169;
			this->lineShape5->Y1 = 234;
			this->lineShape5->Y2 = 149;
			// 
			// lineShape4
			// 
			this->lineShape4->Name = L"lineShape4";
			this->lineShape4->X1 = 173;
			this->lineShape4->X2 = 238;
			this->lineShape4->Y1 = 253;
			this->lineShape4->Y2 = 253;
			// 
			// lineShape3
			// 
			this->lineShape3->Name = L"lineShape3";
			this->lineShape3->X1 = 86;
			this->lineShape3->X2 = 51;
			this->lineShape3->Y1 = 231;
			this->lineShape3->Y2 = 204;
			// 
			// lineShape2
			// 
			this->lineShape2->Name = L"lineShape2";
			this->lineShape2->X1 = 47;
			this->lineShape2->X2 = 86;
			this->lineShape2->Y1 = 173;
			this->lineShape2->Y2 = 109;
			// 
			// lineShape1
			// 
			this->lineShape1->Name = L"lineShape1";
			this->lineShape1->X1 = 108;
			this->lineShape1->X2 = 146;
			this->lineShape1->Y1 = 77;
			this->lineShape1->Y2 = 29;
			// 
			// Form5
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(706, 469);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->close);
			this->Controls->Add(this->Distance);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->button1);
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Form5";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Shortest Path";
			this->Load += gcnew System::EventHandler(this, &Form5::Form5_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
		  public: System::Void color(String^m){
					
		/*	this->label1->BackColor = System::Drawing::Color::White;
			this->label4->BackColor = System::Drawing::Color::White;
			this->label10->BackColor = System::Drawing::Color::White;
			this->label5->BackColor = System::Drawing::Color::White;
			this->label6->BackColor = System::Drawing::Color::White;
			this->label11->BackColor = System::Drawing::Color::White;
			this->label7->BackColor = System::Drawing::Color::White;
			this->label9->BackColor = System::Drawing::Color::White;
			this->label8->BackColor = System::Drawing::Color::White; 

			*/
			 if(m==label3->Text){
			this->label3->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label4->Text){
			this->label4->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label10->Text){
			this->label10->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label5->Text){
			this->label5->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label6->Text){
			this->label6->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label11->Text){
			this->label11->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label7->Text){
			this->label7->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label9->Text){
			this->label9->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label8->Text){
			this->label8->BackColor = System::Drawing::Color::Teal;
		 }
		/*  if(k==label1->Text){
			this->label1->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label4->Text){
			this->label4->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label10->Text){
			this->label10->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label5->Text){
			this->label5->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label6->Text){
			this->label6->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label11->Text){
			this->label11->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label7->Text){
			this->label7->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label9->Text){
			this->label9->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label8->Text){
			this->label8->BackColor = System::Drawing::Color::Teal;
		 }*/
					 }

public: System::Void actualpath(int parent[], int j ) 
{ 
    if (parent[j]== - 1) 
        return; 

	actualpath(parent, parent[j]); 
	 color(names[j]);
     this->Distance->Items->Add(names[j]);
	
} 

	private: System::Void Form5_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
			 
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 	this->label3->BackColor = System::Drawing::Color::White;
			this->label4->BackColor = System::Drawing::Color::White;
			this->label10->BackColor = System::Drawing::Color::White;
			this->label5->BackColor = System::Drawing::Color::White;
			this->label6->BackColor = System::Drawing::Color::White;
			this->label11->BackColor = System::Drawing::Color::White;
			this->label7->BackColor = System::Drawing::Color::White;
			this->label9->BackColor = System::Drawing::Color::White;
			this->label8->BackColor = System::Drawing::Color::White; 

		
			 	 runit^ f1= gcnew runit();
             int* p;
			 int graph[9][9] = {
				     {0, 4, 0, 0, 0, 0, 0, 8, 10}, 
                     {4, 0, 8, 0, 0, 0, 0, 0, 0}, 
                     {0, 8, 0, 7, 0, 0, 0, 0, 0}, 
                     {8, 0, 7, 0, 9, 0, 0, 0, 0}, 
                     {0, 0, 0, 9, 0, 10, 0, 0, 20}, 
                     {0, 0, 0, 0, 10, 0, 2, 0, 0}, 
                     {0, 0, 0, 0, 0, 2, 0, 1, 0}, 
                     {8, 0, 0, 0, 0, 0, 1, 0, 0}, 
                     {10, 0, 0, 0, 20, 0, 0, 0, 0},
                    };
			 
         String^ k=this->comboBox1->Text;
		 String^ m=this->comboBox2->Text;
		 color(k);
		  if(k=="")
			 MessageBox::Show("All fields are compulsory");
		 else  if(m=="")
			 MessageBox::Show("All fields are compulsory");
		 else if(k==m)
			  MessageBox::Show("Current and Destination locations cannot be same");
		 else{
		 int j;
		 int h;
		 for(int i=0;i<9;i++){
		 if(k==names[i])
		 j=i;
		 if(m==names[i])
		 h=i;
		 }
		 	this->Distance->Items->Clear();
	     this->Distance->Items->Add(names[j]);
		 p=f1->dijkstra_for_path(graph, j);
		 this->actualpath(p,h);
		 
		 //while(n != -1){
		  //  this->Distance->Items->Add(n);
		//	 n=p[n];
		 //}
         //this->Distance->Items->Add("The Shortest Distance You have to take ");
	     //this->Distance->Items->Add("to reach "+ m +" from "+ k +" is of "+ *(p+h)+" km"); 
		 }//end else
		 }//end funtion
private: System::Void close_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close();
		 }
};
}
