#pragma once
#include "StdAfx.h"
#include<String>
namespace Map {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	

	/// <summary>
	/// Summary for Form7
	/// </summary>
	public ref class Form7 : public System::Windows::Forms::Form
	{
	public:
		Form7(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form7()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::ListBox^  Nearest_Location;
	private: System::Windows::Forms::Button^  close;
	private: System::Windows::Forms::Panel^  panel2;
	private: Microsoft::VisualBasic::PowerPacks::ShapeContainer^  shapeContainer1;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape13;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape12;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape11;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape10;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape9;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape8;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape5;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape4;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape3;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape2;
	private: Microsoft::VisualBasic::PowerPacks::LineShape^  lineShape1;
	public: System::Windows::Forms::Label^  label5;
	private: 
	public: System::Windows::Forms::Label^  label4;
	public: System::Windows::Forms::Label^  label11;
	public: System::Windows::Forms::Label^  label6;
	public: System::Windows::Forms::Label^  label10;
	public: System::Windows::Forms::Label^  label1;
	public: System::Windows::Forms::Label^  label9;
	public: System::Windows::Forms::Label^  label8;
	public: System::Windows::Forms::Label^  label7;


	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form7::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Nearest_Location = (gcnew System::Windows::Forms::ListBox());
			this->close = (gcnew System::Windows::Forms::Button());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->shapeContainer1 = (gcnew Microsoft::VisualBasic::PowerPacks::ShapeContainer());
			this->lineShape13 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape12 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape11 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape10 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape9 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape8 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape5 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape4 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape3 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape2 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->lineShape1 = (gcnew Microsoft::VisualBasic::PowerPacks::LineShape());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::LightSalmon;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::Red;
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Britannic Bold", 18.2F));
			this->button1->Location = System::Drawing::Point(7, 11);
			this->button1->Margin = System::Windows::Forms::Padding(2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(244, 63);
			this->button1->TabIndex = 2;
			this->button1->Text = L"NEAREST RESTAURANT";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Form7::button1_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::LightSalmon;
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->comboBox3);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Location = System::Drawing::Point(11, 103);
			this->panel1->Margin = System::Windows::Forms::Padding(2);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(240, 197);
			this->panel1->TabIndex = 5;
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Teal;
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(104, 120);
			this->button2->Margin = System::Windows::Forms::Padding(2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 29);
			this->button2->TabIndex = 4;
			this->button2->Text = L"Search";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Form7::button2_Click);
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(4) {L"House 161", L"House 111", L"House 181", L"House 121"});
			this->comboBox3->Location = System::Drawing::Point(91, 66);
			this->comboBox3->Margin = System::Windows::Forms::Padding(2);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(131, 21);
			this->comboBox3->TabIndex = 2;
			// 
			// label3
			// 
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 54);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(75, 37);
			this->label3->TabIndex = 0;
			this->label3->Text = L"Current Location :";
			// 
			// Nearest_Location
			// 
			this->Nearest_Location->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->Nearest_Location->Font = (gcnew System::Drawing::Font(L"Franklin Gothic Medium", 10.2F, System::Drawing::FontStyle::Italic, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->Nearest_Location->FormattingEnabled = true;
			this->Nearest_Location->ItemHeight = 18;
			this->Nearest_Location->Location = System::Drawing::Point(7, 306);
			this->Nearest_Location->Margin = System::Windows::Forms::Padding(2);
			this->Nearest_Location->Name = L"Nearest_Location";
			this->Nearest_Location->Size = System::Drawing::Size(697, 112);
			this->Nearest_Location->TabIndex = 6;
			this->Nearest_Location->SelectedIndexChanged += gcnew System::EventHandler(this, &Form7::Nearest_Location_SelectedIndexChanged);
			// 
			// close
			// 
			this->close->BackColor = System::Drawing::Color::Teal;
			this->close->ForeColor = System::Drawing::Color::White;
			this->close->Location = System::Drawing::Point(629, 437);
			this->close->Name = L"close";
			this->close->Size = System::Drawing::Size(75, 29);
			this->close->TabIndex = 7;
			this->close->Text = L"Close";
			this->close->UseVisualStyleBackColor = false;
			this->close->Click += gcnew System::EventHandler(this, &Form7::close_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::LightSalmon;
			this->panel2->Controls->Add(this->label5);
			this->panel2->Controls->Add(this->label4);
			this->panel2->Controls->Add(this->label11);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->label10);
			this->panel2->Controls->Add(this->label1);
			this->panel2->Controls->Add(this->label9);
			this->panel2->Controls->Add(this->label8);
			this->panel2->Controls->Add(this->label7);
			this->panel2->Controls->Add(this->shapeContainer1);
			this->panel2->Location = System::Drawing::Point(274, 12);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(430, 288);
			this->panel2->TabIndex = 24;
			this->panel2->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form7::panel2_Paint);
			// 
			// label5
			// 
			this->label5->BackColor = System::Drawing::Color::White;
			this->label5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label5.Image")));
			this->label5->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label5->Location = System::Drawing::Point(194, 87);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(87, 32);
			this->label5->TabIndex = 29;
			this->label5->Text = L"House 161";
			this->label5->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label5->Click += gcnew System::EventHandler(this, &Form7::label5_Click);
			// 
			// label4
			// 
			this->label4->BackColor = System::Drawing::Color::White;
			this->label4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label4.Image")));
			this->label4->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label4->Location = System::Drawing::Point(141, 19);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(86, 30);
			this->label4->TabIndex = 28;
			this->label4->Text = L"Bun-B";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label4->Click += gcnew System::EventHandler(this, &Form7::label4_Click);
			// 
			// label11
			// 
			this->label11->BackColor = System::Drawing::Color::White;
			this->label11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label11->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label11.Image")));
			this->label11->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label11->Location = System::Drawing::Point(123, 130);
			this->label11->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(83, 28);
			this->label11->TabIndex = 31;
			this->label11->Text = L"House 121";
			this->label11->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label11->Click += gcnew System::EventHandler(this, &Form7::label11_Click);
			// 
			// label6
			// 
			this->label6->BackColor = System::Drawing::Color::White;
			this->label6->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label6.Image")));
			this->label6->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label6->Location = System::Drawing::Point(235, 242);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(79, 30);
			this->label6->TabIndex = 30;
			this->label6->Text = L"KFC";
			this->label6->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label6->Click += gcnew System::EventHandler(this, &Form7::label6_Click);
			// 
			// label10
			// 
			this->label10->BackColor = System::Drawing::Color::White;
			this->label10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label10->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label10.Image")));
			this->label10->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label10->Location = System::Drawing::Point(317, 123);
			this->label10->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(91, 31);
			this->label10->TabIndex = 33;
			this->label10->Text = L"Optp";
			this->label10->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label10->Click += gcnew System::EventHandler(this, &Form7::label10_Click);
			// 
			// label1
			// 
			this->label1->BackColor = System::Drawing::Color::White;
			this->label1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label1.Image")));
			this->label1->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label1->Location = System::Drawing::Point(273, 51);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(103, 32);
			this->label1->TabIndex = 27;
			this->label1->Text = L"House 111";
			this->label1->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label1->Click += gcnew System::EventHandler(this, &Form7::label1_Click);
			// 
			// label9
			// 
			this->label9->BackColor = System::Drawing::Color::White;
			this->label9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label9->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label9.Image")));
			this->label9->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label9->Location = System::Drawing::Point(1, 181);
			this->label9->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(80, 31);
			this->label9->TabIndex = 26;
			this->label9->Text = L"Ginsoy";
			this->label9->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label9->Click += gcnew System::EventHandler(this, &Form7::label9_Click);
			// 
			// label8
			// 
			this->label8->BackColor = System::Drawing::Color::White;
			this->label8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label8.Image")));
			this->label8->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label8->Location = System::Drawing::Point(79, 239);
			this->label8->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(90, 36);
			this->label8->TabIndex = 32;
			this->label8->Text = L"House 181";
			this->label8->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label8->Click += gcnew System::EventHandler(this, &Form7::label8_Click);
			// 
			// label7
			// 
			this->label7->BackColor = System::Drawing::Color::White;
			this->label7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label7.Image")));
			this->label7->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label7->Location = System::Drawing::Point(35, 85);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(80, 31);
			this->label7->TabIndex = 25;
			this->label7->Text = L"Sams";
			this->label7->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->label7->Click += gcnew System::EventHandler(this, &Form7::label7_Click);
			// 
			// shapeContainer1
			// 
			this->shapeContainer1->Location = System::Drawing::Point(0, 0);
			this->shapeContainer1->Margin = System::Windows::Forms::Padding(0);
			this->shapeContainer1->Name = L"shapeContainer1";
			this->shapeContainer1->Shapes->AddRange(gcnew cli::array< Microsoft::VisualBasic::PowerPacks::Shape^  >(11) {this->lineShape13, 
				this->lineShape12, this->lineShape11, this->lineShape10, this->lineShape9, this->lineShape8, this->lineShape5, this->lineShape4, 
				this->lineShape3, this->lineShape2, this->lineShape1});
			this->shapeContainer1->Size = System::Drawing::Size(430, 288);
			this->shapeContainer1->TabIndex = 0;
			this->shapeContainer1->TabStop = false;
			// 
			// lineShape13
			// 
			this->lineShape13->Name = L"lineShape13";
			this->lineShape13->X1 = 319;
			this->lineShape13->X2 = 275;
			this->lineShape13->Y1 = 141;
			this->lineShape13->Y2 = 113;
			this->lineShape13->Click += gcnew System::EventHandler(this, &Form7::lineShape13_Click);
			// 
			// lineShape12
			// 
			this->lineShape12->Name = L"lineShape12";
			this->lineShape12->X1 = 325;
			this->lineShape12->X2 = 324;
			this->lineShape12->Y1 = 120;
			this->lineShape12->Y2 = 81;
			this->lineShape12->Click += gcnew System::EventHandler(this, &Form7::lineShape12_Click);
			// 
			// lineShape11
			// 
			this->lineShape11->Name = L"lineShape11";
			this->lineShape11->X1 = 163;
			this->lineShape11->X2 = 164;
			this->lineShape11->Y1 = 130;
			this->lineShape11->Y2 = 48;
			this->lineShape11->Click += gcnew System::EventHandler(this, &Form7::lineShape11_Click);
			// 
			// lineShape10
			// 
			this->lineShape10->Name = L"lineShape10";
			this->lineShape10->X1 = 209;
			this->lineShape10->X2 = 208;
			this->lineShape10->Y1 = 88;
			this->lineShape10->Y2 = 46;
			this->lineShape10->Click += gcnew System::EventHandler(this, &Form7::lineShape10_Click);
			// 
			// lineShape9
			// 
			this->lineShape9->Name = L"lineShape9";
			this->lineShape9->X1 = 255;
			this->lineShape9->X2 = 237;
			this->lineShape9->Y1 = 240;
			this->lineShape9->Y2 = 113;
			this->lineShape9->Click += gcnew System::EventHandler(this, &Form7::lineShape9_Click);
			// 
			// lineShape8
			// 
			this->lineShape8->Name = L"lineShape8";
			this->lineShape8->X1 = 217;
			this->lineShape8->X2 = 290;
			this->lineShape8->Y1 = 33;
			this->lineShape8->Y2 = 51;
			this->lineShape8->Click += gcnew System::EventHandler(this, &Form7::lineShape8_Click);
			// 
			// lineShape5
			// 
			this->lineShape5->Name = L"lineShape5";
			this->lineShape5->X1 = 246;
			this->lineShape5->X2 = 166;
			this->lineShape5->Y1 = 242;
			this->lineShape5->Y2 = 157;
			this->lineShape5->Click += gcnew System::EventHandler(this, &Form7::lineShape5_Click);
			// 
			// lineShape4
			// 
			this->lineShape4->Name = L"lineShape4";
			this->lineShape4->X1 = 170;
			this->lineShape4->X2 = 235;
			this->lineShape4->Y1 = 261;
			this->lineShape4->Y2 = 261;
			this->lineShape4->Click += gcnew System::EventHandler(this, &Form7::lineShape4_Click);
			// 
			// lineShape3
			// 
			this->lineShape3->Name = L"lineShape3";
			this->lineShape3->X1 = 83;
			this->lineShape3->X2 = 47;
			this->lineShape3->Y1 = 239;
			this->lineShape3->Y2 = 211;
			this->lineShape3->Click += gcnew System::EventHandler(this, &Form7::lineShape3_Click);
			// 
			// lineShape2
			// 
			this->lineShape2->Name = L"lineShape2";
			this->lineShape2->X1 = 44;
			this->lineShape2->X2 = 87;
			this->lineShape2->Y1 = 181;
			this->lineShape2->Y2 = 111;
			this->lineShape2->Click += gcnew System::EventHandler(this, &Form7::lineShape2_Click);
			// 
			// lineShape1
			// 
			this->lineShape1->Name = L"lineShape1";
			this->lineShape1->X1 = 105;
			this->lineShape1->X2 = 143;
			this->lineShape1->Y1 = 85;
			this->lineShape1->Y2 = 37;
			this->lineShape1->Click += gcnew System::EventHandler(this, &Form7::lineShape1_Click);
			// 
			// Form7
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(716, 501);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->close);
			this->Controls->Add(this->Nearest_Location);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->button1);
			this->Name = L"Form7";
			this->Text = L"Nearest Restaurant";
			this->Load += gcnew System::EventHandler(this, &Form7::Form7_Load);
			this->panel1->ResumeLayout(false);
			this->panel2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void close_Click(System::Object^  sender, System::EventArgs^  e) {
				 this->Close();
			 }
			  public: System::Void color(String^m,String ^k){
					
			this->label1->BackColor = System::Drawing::Color::White;
			this->label4->BackColor = System::Drawing::Color::White;
			this->label10->BackColor = System::Drawing::Color::White;
			this->label5->BackColor = System::Drawing::Color::White;
			this->label6->BackColor = System::Drawing::Color::White;
			this->label11->BackColor = System::Drawing::Color::White;
			this->label7->BackColor = System::Drawing::Color::White;
			this->label9->BackColor = System::Drawing::Color::White;
			this->label8->BackColor = System::Drawing::Color::White; 


			 if(m==label1->Text){
			this->label1->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label4->Text){
			this->label4->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label10->Text){
			this->label10->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label5->Text){
			this->label5->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label6->Text){
			this->label6->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label11->Text){
			this->label11->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label7->Text){
			this->label7->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label9->Text){
			this->label9->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(m==label8->Text){
			this->label8->BackColor = System::Drawing::Color::Teal;
		 }
		  if(k==label1->Text){
			this->label1->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label4->Text){
			this->label4->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label10->Text){
			this->label10->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label5->Text){
			this->label5->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label6->Text){
			this->label6->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label11->Text){
			this->label11->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label7->Text){
			this->label7->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label9->Text){
			this->label9->BackColor = System::Drawing::Color::Teal;
		 }
		 else  if(k==label8->Text){
			this->label8->BackColor = System::Drawing::Color::Teal;
		 }
					 } 
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			  	
			 int graph[9][9] = {
		/*bun b*/		     {0, 4, 0, 0, 0, 0, 0, 8, 0}, 
    /*house 111*/            {4, 0, 8, 0, 0, 0, 0, 11, 0}, 
            /*optp*/         {0, 8, 0, 7, 0, 4, 0, 0, 2}, 
            /*house 161*/    {0, 0, 7, 0, 9, 14, 0, 0, 0}, 
    /*kfc*/                  {0, 0, 0, 9, 0, 10, 0, 0, 0}, 
     /*house 181*/           {0, 0, 4, 0, 10, 0, 2, 0, 0}, 
   /*ginsoy*/                {0, 0, 0, 14, 0, 2, 0, 1, 6}, 
   /*sams*/                  {8, 11, 0, 0, 0, 0, 1, 0, 7}, 
    /*house 121*/            {0, 0, 2, 0, 0, 0, 6, 7, 0},
                    };

			  array<String^>^ names = gcnew array<String^>(9);
				    names[0]="Bun-B";
					names[1]="House 111";
					names[2]="Optp";
					names[3]="House 161";
					names[4]="KFC";
					names[5]="House 181";
					names[6]="Ginsoy";
					names[7]="Sams";
					names[8]="House 121";
			 
         String^ n=this->comboBox3->Text;
		  if(n=="")
			 MessageBox::Show("This field is compulsory");
		  else{
		 int j;
		
		 int r;
		   String^ d;
		 for(int i=0;i<9;i++){
		 if(n==names[i])   //getting the index of current location
		 j=i;
		 }
		 int i;
		 for(  i=1;graph[j][i]==0;i++){
		 }
		 int min=graph[j][i];//to get first non zero value
		  for(i;i<9;i++){
   			    if(graph[j][i]<min){
				if(graph[j][i]!=0){
					if(names[i][0]!=72){
				 min=graph[j][i];
				r=i;//index of the shortest distance
				}//end if
				}
				}//end if
		 }//end for
		
		d=names[r];
		color(n,d);
		   this->Nearest_Location->Items->Clear();
		 this->Nearest_Location->Items->Add("The Nearest Restaurant from your current location is : ");
	    this->Nearest_Location->Items->Add(d); 
		 this->Nearest_Location->Items->Add("It's distance from here is "+min+" km");
		  }//else
		 }//end function
		
private: System::Void Form7_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Nearest_Location_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label7_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label9_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label11_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label8_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label6_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label10_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void panel2_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
		 }
private: System::Void lineShape1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape11_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape10_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape12_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape8_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape13_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape9_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape5_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lineShape2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
