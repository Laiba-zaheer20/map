#pragma once
#define V 9

ref class runit
{
public:
	
	runit(void);
	int pak(void);
	int runit::min(int dist[],bool sptSet[]);
	int* runit::dijkstra_for_distance(int graph[V][V], int src) ;
	int* runit::dijkstra_for_path(int graph[V][V], int src) ;
	int* runit::matrixsall(int source);
};

